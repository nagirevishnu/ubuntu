#include<stdio.h>
#include<stdlib.h>
int main()
{
	int arr1[][5]={{1,2,3,4,5},{6,7,8,9,1},{2,3,1,3,4},{3,5,4,6,5},{6,8,7,3,2}};
	//int arr2[3][3]={{0,0,0},{1,1,1},{1,0,1}};
	int rows,col;
	printf("kernel rows&col\n");
	printf("enter rows:");
	scanf("%d",&rows);
	printf("enter coloumns:");
	scanf("%d",&col);
	int**arr2 = (int**)malloc(rows * sizeof(int));
	for (int i = 0; i < rows; i++)
	{
		 arr2[i]=(int*)malloc(col * sizeof(int));
		for(int j=0;j<col;j++)
		{
			scanf("%d",&arr2[i][j]);
		}
	}
	printf("kernel matrix\n");
	for (int i = 0; i < rows; i++)
        {
                for(int j=0;j<col;j++)
                {
                        printf("%d ",arr2[i][j]);
                }
		printf("\n");
        }

	int res[5-rows+1][5-col+1],sum=0;
	for(int i=0;i<5-rows+1;i++)
	{
		for(int j=0;j<5-col+1;j++)
		{
			sum=0;
			for(int k=0;k<rows;k++)
			{
				for(int g=0;g<col;g++)
				{
					sum+=arr1[i+k][j+g]*arr2[k][g];
				}
			}
			printf("sum:%d\n",sum);
			res[i][j]=sum;
		}
	}
	printf("2d convolution matrix\n");
	for(int i=0;i<5-rows+1;i++)
	{
		for(int j=0;j<5-col+1;j++)
		{
			printf("%d ",res[i][j]);
		}
		printf("\n");
	}

}




