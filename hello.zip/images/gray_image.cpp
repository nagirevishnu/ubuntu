#include <opencv2/opencv.hpp>
#include <iostream>

int main() {
    // Load the image
    std::string inputFile = "WIN_20241122_14_41_04_Pro.jpg";
    cv::Mat image = cv::imread(inputFile, cv::IMREAD_COLOR); // Load as a color image

    // Check if the image is loaded successfully
    if (image.empty()) {
        std::cerr << "Error: Could not open or find the image!" << std::endl;
        return -1;
    }

    // Display the original image
    cv::imshow("Original Image", image);
    cv::waitKey(0); // Wait for a key press

    // Process the image (e.g., convert to grayscale)
    cv::Mat grayImage;
    cv::cvtColor(image, grayImage, cv::COLOR_BGR2GRAY);

    // Save the processed image
    std::string outputFile = "output2.jpg"; // Path to the output image
    if (cv::imwrite(outputFile, grayImage)) {
        std::cout << "Image saved successfully: " << outputFile << std::endl;
    } else {
        std::cerr << "Error: Could not save the image!" << std::endl;
        return -1;
    }

    // Display the processed image
    cv::imshow("Processed Image", grayImage);
    cv::waitKey(0); // Wait for a key press

    return 0;
}
