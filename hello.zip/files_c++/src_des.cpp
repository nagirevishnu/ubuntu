#include<iostream>
#include<fstream>
using namespace std;

int main(int argc ,char *argv[])
{
	ifstream src;
	ofstream dest;
	src.open(argv[1]); // file opened in read mode
	dest.open(argv[2]); // file opened in write mode
	char str[100];
	while(!src.eof())
	{
	src>>str;
	dest<<str;
	}
	src.close();
	dest.close();
}
