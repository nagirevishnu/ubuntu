/*#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, char *argv[])
{
    if (argc != 3) {
        cout << "Usage: " << argv[0] << " <source file> <destination file>" << endl;
        return 1;
    }

    ifstream src(argv[1]);
    ofstream dest(argv[2]);

    if (!src.is_open() || !dest.is_open()) {
        cout << "Error opening files." << endl;
        return 1;
    }

    string str;
    while (src >> str) {
        dest << str <<endl;
    }

    src.close();
    dest.close();

    cout << "File copied successfully." << endl;
    return 0;
}*/
#include<iostream>
#include<fstream>
using namespace std;

int main(int argc ,char *argv[])
{
	ifstream src;
	ofstream dest;
	src.open(argv[1]); // file opened in read mode
	dest.open(argv[2]); // file opened in write mode
	char ch;
	ch=src.get();
	//printf("%s",&ch);
	while((ch=src.getline())!=EOF)
	{
		printf("%s",&ch);
		dest.put(ch);
	}
	src.close();
	dest.close();
}


