dict={
        "table":("a piece of furtune","list of facts","figure"),
        "cat":"a small animal"}
print(dict)
dict1={
        "table":["a piece of furtune","list of facts","figure"],
        "cat":"a small animal"}
print(dict1)

