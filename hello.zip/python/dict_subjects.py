dict={}
i=0
while i<3:
    m=int(input("enter the subject marks:"))
    n=input("enter subject:")
    dict.update({n:m})
    i+=1
print(dict)
