var=(4,)
print(type(var))
