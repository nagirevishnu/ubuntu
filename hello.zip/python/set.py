#set is unorder,so compile again&again u got different output
set={1,2,3,2,1,"vishnu","ravi","ravi",4}
print(set)
