tuple=(1,4,4,4,2,5)
print(tuple)
print(type(tuple))
mark=(1)
print(mark)
print(type(mark))

#sliceing

print(tuple[0:])
print(tuple[:8])
print(tuple[-1:])
print(tuple[:-1])

#index
print(tuple.index(4))
print(tuple.index(5))

#count
print(tuple.count(4))

