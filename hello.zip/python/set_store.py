
set={9,9.0}
print(set)
set={(9,9.0)}
print(set)
tup=(1,2,3,1,1.0)
print(tup.count(1))
