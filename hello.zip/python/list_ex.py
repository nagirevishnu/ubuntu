marks=[1,20.3,"vishnu",33.887,"reddy"]
print(marks)
print(type(marks))
print(len(marks))
print(marks[3])
print(marks[-1])
marks[1]='''nagire'''
print(marks)

print(marks[1:])
print(marks[:3])
print("\n")
print(marks[:-6])
