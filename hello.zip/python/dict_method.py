#key(return keys)
vishnu={
        "name":"vardhan",
        "roll":{
            "ravi":409,
            "ramu":410
            },
        "sal":13000
        }
print(vishnu.keys())
print(type(vishnu))
print(list(vishnu.keys()))
print(len(list(vishnu.keys())))
print(tuple(vishnu.keys()))
print(len(vishnu))

#values(return values)
print(vishnu.values())
print(list(vishnu.values()))
print(len(list(vishnu.values())))
print(tuple(vishnu.values()))
print(len(vishnu))

#items(returns keys and values)
print(vishnu.items())
n=list(vishnu.items())
print(n[1])

#get(returns key)
print(vishnu["name"])
print(vishnu.get("name"))
print(vishnu.get("name1"))

#update(inseret required elements)
vishnu.update({"place":"gachi","bus":10} )
print(vishnu)


