#append  sort

list1=[3,66,75,3,2]
print(list1) 
list1.append(8)
print(list1)
print(list1.append(9))
print(list1)

#sorting list
list1.sort()
print(list1)
print(list1.sort())
print(len(list1))

#sorting in desending order
print(list1.sort(reverse=True))
print(list1)
print("\n");
list2=["vishnu","venu","gova","loki"]
print(list2)
list2.sort()
print(list2)
list2.sort(reverse=True)
print(list2)

#reverse
print(list2.reverse())
print(list2)

#insert
print(list2.insert(5,"nagire"))
print(list2)
print(len(list2))

#remove
list2.remove("gova")
print(list2)

#pop
list2.pop(1)
print(list2)

