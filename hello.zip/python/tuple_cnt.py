tuple=("c","d","a","c","d","c")
print(tuple)
print(tuple.count('c'))



