def fun(a):
    list.append(a)
 
list=[]
n=int(input("enter the list size:"))
for i in range(n):
    m=int(input("enter the list element:"))
    fun(m)
print(list)

