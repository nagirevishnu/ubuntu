#alpha=[]
#symbals=[]
#numbers=[]
def fun(a):
    alpha=[]
    symbals=[]
    numbers=[]
    c=len(a)
    for i in range(c):
        if a[i]>='a' and a[i]<='z':
            alpha.append(a[i])
        elif a[i]>='0'and a[i]<='9':
            numbers.append(a[i])
        else:
            symbals.append(a[i])
    print(alpha)
    print(numbers)
    print(symbals)
#alpha=[]
#numbers=[]
#symbals=[]
n=input("enter the string:")
fun(n)
print(alpha)
print(numbers)
print(symbals)

