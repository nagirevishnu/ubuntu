'''def fun(a,b):
    c=len(a)
    v=len(b)
    i=0
    j=0
    while i<c and j<v:
        print(a[i],end="")
        print(b[j],end="")
        i+=1
        j+=1
list1=['a','b','c','d','e']
list2=[1,2,3,4,5]
fun(list1,list2)'''

'''def fun(a,b):
    c=[]
    v=-1
    for i in range(len(a)):
        c.append(a[i])

    for i in range(len(b)):
        v=v+2
        c.insert(v,b[i])
    print(c)
    return c

list1=['a','b','c','d','e','g','h','j','k']
list2=[1,2,3,4,6,7,8,8,9,7,4,33,3,2,4,6,6.6,768,88,4,5]
j=fun(list1,list2)
print(' '.join(map(str,j)))'''

def fun(a,b):
    v=-1
    for i in b:
        v=v+2
        a.insert(v,i)
    print(' '.join(map(str,a)))


a=list(map(int,input()))
b=list(map(str,input()))
fun(a,b)

