def fun(a):
    for i in range(1,a+1):
        if i%2==1:
            c=i**2
            dict.update({i:c})
        

dict={}
n=int(input("enter the number:"))
v=fun(n)
print(dict)
print(dict.items())
