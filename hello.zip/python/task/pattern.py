'''def fun(a):
    for i in range(a,0,-1):
        for j in range(0,a+1):
            if(i<=j):
                print("*",end="")
            else:
                print(" ",end="")
        print(" ")
        '''
def fun(a):
    for i in range(1,a+1):
        print(' '*(a-i),'*'*i)
        #print('*'*i,' '*(a-i))
        
        
        
        

n=int(input("enter pattern size:"))
fun(n)
