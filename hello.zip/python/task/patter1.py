def fun(n):
     for i in range(1,n+1):
            print("*"*n)
    #for i in range(n):
     #   for j in range(n):
      #      print("*",end="")
       # print(" ")'''

n=int(input("enter pattern size:"))
fun(n)
