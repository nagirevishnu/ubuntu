'''def fun(a):
    i=0
    c=0
    while i<=31:
        if (a>>i)&1:
            print(
        print((a>>i)&1,end="")
        i+=1


n=int(input("enter the required binary number:"))
#m=int(input("enter the number size 4 or 8:"))
fun(n)'''


def fun(a):
    print(bin(a)[2:])
n=int(input("enter the number:"))
fun(n)


