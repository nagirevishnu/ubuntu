a=set()
print(type(a))
dict={}
print(type(dict))
