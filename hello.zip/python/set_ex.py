#how many classes required for different subjects
set={"c","c++","java","c","c++","python"}
print(len(set))
