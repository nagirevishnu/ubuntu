'''def s(func):
    def inner():
        str1=func()
        return str1.upper()
    return inner

def p():
    return "vishnu"
print(p())
d=s(p)
print(d)'''


def s(func):
    print(func())
    def inner():
        str1=func()
        return str1.upper()
    return inner
@s
def p():
    return "vishnu"
print(p())
#d=s(p)
#print(d)
