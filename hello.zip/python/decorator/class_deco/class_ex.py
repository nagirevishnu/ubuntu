class decorator:
    def __init__(self,name,r,e):
        self.name=name
        self.r=r
        self.e=e
    #def fun(self):
    def __call__(self):
        print(self.name)
    def __call__(self):
        print(self.r)
    #def __call__(self):
     #   print(self.name)
obj=decorator(4,"vishnu",33)
obj()
