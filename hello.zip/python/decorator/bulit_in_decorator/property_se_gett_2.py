class Student:
    def __init__(self,marks):
        self.__marks=marks
    def per(self):
        return ((self.__marks/600)*100)
    def getter(self):
        print("getting value",end=" ")
        return self.__marks
    def setter(self,value):
        if value<0 or value>600:
            print("enter valid value")
        else:
            print("setting value:",value)
            self.__marks=value
    marks=property(getter,setter)
obj=Student(300)
obj.marks=206
print(obj.marks)
print(obj.per(),"%")
