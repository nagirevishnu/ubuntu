class Student:
    def __init__(self,name,grade):
        self.name=name
        self.grade=grade
    @property
    def method(self):
        return self.name+"got"+self.grade
obj=Student("vishnu",'A')
#obj.grade='b'
print(obj.name)
print(obj.grade)
print(obj.method)
