class Student:
    def __init__(self,marks):
        self.__marks=marks
        #self.grade=grade
        #self.marks=marks
    def per(self):
        return (self.__marks/600)*100
    #def method(self):
     #   return self.name+"got "+self.grade,self.marks
    @property
    def marks(self):
        print("getting value",end=" ")
        return self.__marks
    @marks.setter
    def marks(self,value):
        if value<0 or value>600:
            print("enter valid value")
        else:
            print("setting value:",value)
        self.__marks=value
obj=Student(300)
#obj.grade='b'
obj.marks=2060
#print(obj.name)
#print(obj.grade)
print(obj.marks)
print(obj.per(),"%")
