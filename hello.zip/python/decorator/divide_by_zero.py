#import functools
def divison(func):
    #@functools.wraps(func)
    def inner(*args):
        list=[]
        list=args[1:]
        for i in list:
            if i==0:
                print("give non zero value:")
        return func(*args)
    return inner
@divison
def div2(a,b,c):
    return a/b/c
@divison
def div(a,b):
    return a/b
print(div(5,5))
print(div2(1,3,8))
print(div.__name__)
print(div2.__name__)
