def div_zero(func):
    def inner(a,d):
        if d==0:
            return "give non zero value\n"
        return a/d
    return inner
@div_zero
def div(a,b):
    return a/b
n=int(input("enter number1:"))
m=int(input("enter number2:"))
print(div(n,m))
