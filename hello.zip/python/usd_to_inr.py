def fun(m):
    print(m*83
m=int(input("enter the usd number:"))
fun(m)


fun(m):
    print(m)
