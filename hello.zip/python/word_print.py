m="vishnu vardhan reddy"
l=len(m)
print(l)
c=0
for i in range(l):
    if(m[i]==" "):
        print(m[c:i])
        c=i+1
print(m[c:])



