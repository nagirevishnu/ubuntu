dict={
        "name":5,
        "roll":"r&d enge",
        "salary":13000,
        "company":"zenteree",
        "age":21,
        "cgpa":7.9,
        "name":88,
        tuple:('f',3,9.9),
        list:["vishnu",3,9.9],
        88.88:77
        }
print(dict)
'''dict["name"]="vardhan"
print(dict)
print(dict["salary"])'''
