for i in range(0,4,1):
    for j in range(0,4,1):
        if i%2==0:
            if i<=j:
                print(chr(65+j),end="")
            else:
                print(" ",end="")
        elif i%2==1:
            if i>j:
                print(" ",end="")
            elif i<=j:
                print(j,end="")
            else:
                print(j+1
    print(" ")

            



