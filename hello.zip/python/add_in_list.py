movies=[]
n=(input("enter the movie1:"))
m=(input("enter the movie2:"))
p=(input("enter the movie3:"))
movies.append(n)
movies.append(m)
movies.append(p)
print(movies)
