"""list=[]
i=0
n=int(input("enter the list size:"))
while i<n:
    m=int(input("enter the list elements:"))
    list.append(m)
    i+=1;
list1=list.copy()
print(list1)
list.reverse()
print(list)
if list==list1:
    print("palindrome")
else:
    print("not")"""


list=[]
i=0
n=int(input("enter the list size:"))
while i<n:
    list.append(int(input("enter the list elements:")))
    i+=1;
list1=list.copy()
print(list1)
list.reverse()
print(list)
if list==list1:
    print("palindrome")
else:
    print("not")
