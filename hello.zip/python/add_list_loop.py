movies=[]
n=int(input("enter the how many movies:"))
i=0;
while i<n:
    m=input("enter the movie:")
    movies.update(m)
    i+=1;
if n==0:
    print("invalid input");
    exit(0);
print(movies)


for i in range(n):
    m=input("enter the movies:")
    movies.append(m)
print(movies)



