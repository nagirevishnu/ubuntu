def fun(a):
    c=1
    i=1
    do:
        c=i*c
        while i<=a:
        
    return c

n=int(input("enter the factorial number:"))
a=fun(n)
print(a)

