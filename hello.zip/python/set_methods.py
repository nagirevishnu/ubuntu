#add
'''set={1,4,"vishnu",5,"ravi"}
print(set)
set.add(5)
set.add(8)
set.add("ramu")
set.add((1,3,4,9))
#set.add([1,3,4,9]) list is not print
print(set)

#remove
set.remove(1)
print("\n")
print(set)

#clear(it clear all data)
set.clear()
print(set)

#pop(returns differnet element)
set.pop()
print(set)'''

#union(returns non duplicate)
set1={1,3,2,3}
set2={4,5,8,1,3,9}
print(set1.union(set2))
print(set1)
print(set2)

#intersection
print(set1.intersection(set2))
