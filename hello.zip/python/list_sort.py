list=['v','i','s','h','n','u']
list.sort()
print(list)
