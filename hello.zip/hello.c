#include<stdio.h>
int main()
{
	printf("vishnu\n");
}
