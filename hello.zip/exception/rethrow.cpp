#include<iostream>
using namespace std;

void fun(int a)
{
	try
	{	cout<<"inner try block:"<<endl;
		if(a%2)
			throw a;
		cout<<"a:"<<a<<endl;
	}
	catch(int x)
	{	cout<<"inner catch:"<<endl;
		throw ++x;
	}
}
int main()
{
	int num;
	cout<<"enter the num:"<<endl;
	cin>>num;
	try
	{
		cout<<"in outer try block:"<<endl;
		fun(num);
		cout<<"num:"<<num<<endl;
	}
	catch(int n)
	{
		cout<<"in outer catch:"<<endl;
		cout<<n<<endl;
	}
}

