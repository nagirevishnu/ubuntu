#include <iostream>
using namespace std;
enum Level{low,medium,high}; 
int main() 
{
  enum Level myVar = high;
  cout << myVar;
  return 0;
}
