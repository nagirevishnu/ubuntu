#include<iostream>
using namespace std;
int main()
{
	int num;
	int sum;
	cout<<"enter the num:"<<endl;
	cin>>num;
	while(num)
	{
		sum+=num%10;
		num=num/10;
	}
	cout<<"sum:"<<sum<<endl;
	cout<<"Program completed:"<<endl;

}
