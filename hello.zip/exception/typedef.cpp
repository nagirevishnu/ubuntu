#include<iostream>
using namespace std;
int main()
{
	typedef unsigned long long int s;
	s var=10002;
	cout<<var<<endl;
}
