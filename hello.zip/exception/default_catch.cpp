#include<iostream>
using namespace std;
void test(int data)
{
	static char str[]="vector";
	string s1="embedded";
	if(data==1)
		throw 'A';
	else if(data==2)
		throw 123;
	else if(data==3)
		throw 5.6f;
	else if(data==4)
		throw 67.8;
	else if(data==5)
		throw str;
	else if(data==6)
		throw s1;
	
}
int main()
{
	int field;
	cout<<"enter the field:"<<endl;
	cin>>field;
	try
	{
		test(field);
	}
	catch(char x)
	{
		cout<<"Character catch:"<<x<<endl;
	}
	/*catch(int x)
	{
		cout<<"Integer catch:"<<x<<endl;
	}*/
	catch(float x)
	{
		cout<<"float catch:"<<x<<endl;
	}
	catch(double x)
	{
		cout<<"double catch:"<<x<<endl;
	}
	catch(char *x)
	{
		cout<<"C style string catch:"<<x<<endl;
	}
	catch(string x)
	{
		cout<<"C++ Style string catch:"<<x<<endl;
	}
	catch(...)
	{
		cout<<"Exception occurred:"<<endl;
	}
}
