#include<iostream>
using namespace std;
int main()
{
	int num,den,res;
	cout<<"enter the number:"<<endl;
	cin>>num;
label :cout<<"enter the denominator:"<<endl;
	cin>>den;
	try
	{	if(den==0)
		throw den;

		res=num/den;
		cout<<"res:"<<res<<endl;
	}
	catch(int d)
	{
		cout<<"Divisible by zero not possible:"<<endl;
		cout<<"enter the non zero value as denominator:"<<endl;
		goto label;
	}

	cout<<"Program completed :"<<endl;
}
