#include <iostream> 
using namespace std; 
union student {int age;char GPA;int marks;}; 
int main() 
{ 
       student vishnu;	
	cout<<"enter age:";
        cin>>vishnu.age;
	cout<<"enter GPA:";
        cin>>vishnu.GPA;
	cout<<"enter marks:";
        cin>>vishnu.marks;
    	cout << "Memory address of marks: " <<vishnu.marks << endl; 
    	cout << "Memory address of age: " <<vishnu.age << endl; 
    	cout << "Memory address of gpa: " <<vishnu.GPA << endl; 
    	cout << "Size of a union: " << sizeof(student) << endl; 

}
