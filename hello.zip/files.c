#include <stdio.h>
#include <errno.h>
#include <string.h>

int main()
{
FILE *fp =NULL;
fp=fopen("n.txt", "r");
printf("%d",fp);
if(fp ==NULL) 
{
    printf("Error: %s\n", strerror(errno));  // Prints error code
}
printf("%s",fp);

}
/*#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include<string.h>
int main() {
    errno = 0;  // Clear errno
    void *ptr = malloc(100000000000);  // Try to allocate a huge amount
    if (ptr == NULL) {
        printf("Memory allocation failed:%i %s\n",errno,strerror(errno));
    }
    return 0;
}*/


