#include"header.h"
int main()
{
	int n;
	printf("enter the araay size\n");
	scanf("%d",&n);
	int arr[n];
