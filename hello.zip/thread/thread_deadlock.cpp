#include<iostream>
#include<mutex>
#include<thread>
#include<chrono>
using namespace std;
using namespace std::chrono;
std::mutex m1;
std::mutex m2;
void fun1()
{
	m1.lock();
	//std::this_thread::sleep_for(std::chrono::seconds(1));
	m2.lock();
	cout<<"thread 1 executed"<<endl;
	m1.unlock();
        m2.unlock();
}
void fun2()
{
        m2.lock();
	//std::this_thread::sleep_for(std::chrono::seconds(1));
        m1.lock();
        cout<<"thread 2 executed"<<endl;
        m2.unlock();
        m1.unlock();
}
int main()
{
	thread t1(fun1);
	thread t2(fun2);
	t1.join();
	t2.join();
}
