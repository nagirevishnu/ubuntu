#include<iostream>
#include<thread>
using namespace std;
void fun(int x)
{
    int temp=x,res=0;
    while(temp)
    {
        res=res*10+temp%10;
        temp=temp/10;
    }
    cout<<res<<endl;
}
 
void fun2(int x)
{
    int temp=x,res=0;
    while(temp)
    {
        res=res*10+temp%10;
        temp=temp/10;
    }
    cout<<res<<endl;
}
int main()
{
    int number=100;
    thread t1(fun,number);
    thread t2(fun2,number);
    t1.join();
    t2.join();
 
}
