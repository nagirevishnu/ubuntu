#include<iostream>
#include<chrono>
#include<mutex>
#include<thread>
using namespace std;
std::timed_mutex m;
int j=0;
void fun(int x)
{
	if(m.try_lock_for(std::chrono::seconds(2)))
	{
		j++;		
		std::this_thread::sleep_for(std::chrono::seconds(2));
		cout<<"in thread"<<x<<"enter"<<endl;
		m.unlock();
	}
	else
		cout<<"in thread"<<x<<"doesn't enter"<<endl;
}
int main()
{
	thread t1(fun,1);
	thread t2(fun,2);
	t1.join();
	t2.join();
	cout<<"j:"<<j<<endl;
}
