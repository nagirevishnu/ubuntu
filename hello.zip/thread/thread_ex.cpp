#include<iostream>
#include<ctime>
#include<chrono>
#include<thread>
using namespace std;
typedef chrono::milliseconds msec;
typedef chrono::high_resolution_clock  hrc;
void fun(int i,int j)
{
    for(;i<j;i++)
    {
        cout<<char(i)<<" ";
    }
}
void fun1(int i,int j=95)
{
    for(;i<j;i++)
    {
        cout<<i<<" ";
    }
//    cout<<endl;
}
int main()
{
    int start=hrc::now();
    int start_char=65,end_char=91;
    fun(start_char,end_char);
    fun1(start_char,end_char);
    //thread t1(fun,start_char,end_char);
    //thread t2(fun1,start_char,end_char);
    //t1.join();
    //t2.join();
    int end=hrc::now();
    int exec_time=chrono::duration_cast<msec>(end-start);
    cout<<"execution time:"<<exec_time.count()<<endl;
}
