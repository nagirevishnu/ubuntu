//funtion pointer
#include<iostream>
#include<thread>
/*void fun(int x)
{
	while(x-->0)
		std::cout<<x<<" ";
}
int main()
{
	std::thread t1(fun,10);
	t1.join();
}*/
auto fun=[](int x)
{
	while(x-->0)
		std::cout<<x<<" ";
};

int main()
{
	std::thread t(fun,10);
	t.join();
}
