#include<iostream>
#include<ctime>
#include<thread>
#include<chrono>
using namespace std;
//typedef chrono::milliseconds msec;
//typedef chrono::high_resoultion_clock hrc;
void fun(int *arr)
{
    for(int i=0;i<6;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;

}
void fun2(int *arr)
{
    for(int i=0;i<6;i++)
    {
        if((i&1)==0)
        {
            cout<<arr[i]<<" ";
        }
    }

 }
int main()
{
	typedef chrono::milliseconds msec;
	typedef chrono::high_resoultion_clock hrc;
	auto start=hrc::now();
	int arr[]={1,2,3,4,6,7};
	//auto start=hrc::now();
	thread t1(fun,arr);
	thread t2(fun2,arr);
	t1.join();
    t2.join();
	auto end=hrc::now();
	auto exec_time=chrono::duration_cast<msec>(end-start);
	cout<<exec_time.count()<<endl;
    	//t1.join();
    	//t2.join();
}
