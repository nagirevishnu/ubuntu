#include <gst/gst.h>

int main(int argc, char *argv[])
{
  GstElement *pipeline, *source, *sink ,*decoder;
  GstBus *bus;
  GstMessage *msg;
  GstStateChangeReturn ret;

  gst_init (&argc, &argv);

  source = gst_element_factory_make ("v4l2src", "source");
  sink = gst_element_factory_make ("autovideosink", "sink");
  decoder= gst_element_factory_make("videoconvert","decoder");


  pipeline = gst_pipeline_new ("test-pipeline");

  if (!pipeline || !source || !sink || !decoder) {
    g_printerr ("Not all elements could be created.\n");
    return -1;
  }

  gst_bin_add_many (GST_BIN (pipeline),source,decoder,sink, NULL);

  if (gst_element_link_many(source,decoder,sink,NULL) != TRUE) {
    g_printerr ("Elements could not be linked.\n");
    gst_object_unref (pipeline);
    return -1;
  }


  ret = gst_element_set_state (pipeline, GST_STATE_READY);
  if (ret == GST_STATE_CHANGE_FAILURE) {
    g_printerr ("Unable to set the pipeline to the playing state.\n");
    gst_object_unref (pipeline);
    return -1;
  }

  bus = gst_element_get_bus (pipeline);
  msg =
      gst_bus_timed_pop_filtered (bus, GST_CLOCK_TIME_NONE,
      GST_MESSAGE_ERROR | GST_MESSAGE_EOS);

  gst_message_unref (msg);
  gst_object_unref (bus);
  gst_element_set_state (pipeline, GST_STATE_NULL);
  gst_object_unref (pipeline);
  return 0;
}


