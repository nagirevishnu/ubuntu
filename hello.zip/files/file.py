f1=open("data,txt","w")
f1.write("vishnu")
