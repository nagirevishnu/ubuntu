#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<errno.h>
#include<termios.h>
#include<fcntl.h>
int main()
{
	int fd=open("/dev/ttyS0",O_RDWR);
	if(fd<0)
	{
		perror("fd");
		return 1;
	}
	printf("%d",fd);
	struct termios tty;
	if(tcgetattr(fd,&tty)!=0)
	{
		printf("error %i at %s\n",errno,strerror(errno));
		return 1;
	}
	tty.c_cflag|=(CREAD|CLOCAL);
	tty.c_cflag&=~(CRTSCTS|CSIZE|CSTOPB|PARENB);
	tty.c_cflag|=CS8;
	tty.c_oflag&=~(OPOST|ONLCR);
	tty.c_iflag&=~(IGNBRK|ISTRIP|BRKINT|INLCR|IXON|IXOFF|PARMRK|ICRNL|IXANY);
	tty.c_lflag&=~(ECHO|ECHOE|ECHONL|ISIG|ICANON);
	/*tty.c_lflag=0;
	tty.c_iflag=0;
	tty.c_oflag=0;*/
	tty.c_cc[VMIN]=0;
	tty.c_cc[VTIME]=10;
	cfsetispeed(&tty,B115200);
	cfsetospeed(&tty,B115200);
	if(tcsetattr(fd,TCSANOW,&tty)!=0)
	{
		perror("tcsetattr");
		return 1;
	}
	while(1)
	{
		char ch=getchar();
		write(fd,&ch,sizeof(ch));
		char s;
		int n=read(fd,&s,sizeof(s));
		if(n<0)
		{
			printf("%s\n",strerror(errno));
			return 1;
		}
	}
	close(fd);
}





