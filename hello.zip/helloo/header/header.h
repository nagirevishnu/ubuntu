#include<iostream>
#include<fstream>
#include<ctime>
using namespace std;
class merge
{
	public:
		merge(int*,int,int );
	        void merge_sort(int*,int,int,int);
};
